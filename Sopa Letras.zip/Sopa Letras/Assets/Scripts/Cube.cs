﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube : MonoBehaviour {

	// Use this for initialization
	public GameObject cube;
	public GameObject soup;
	public Texture2D[,] texture = new Texture2D[9,8];
	public Texture2D[] letters = new Texture2D[26];
	public int w=2;

	void Start () {

		for (int y = 0; y <= 8; y++) {
			for (int i = 0; i <= 7; i++) {
				soup = Instantiate (cube);
				soup.transform.position = new Vector3 (i, y, 0);
				soup.GetComponent<Renderer> ().material.mainTexture = letters [Random.Range (0, 26)];
				soup.gameObject.tag = "Blue";
			}

		}
		//if (Random.Range (0, 1) == 1) {
		int x = Random.Range (0, 8);
		int j = Random.Range (0, 4);

		int p = Random.Range (0, 3);
		if (p == 0) {
			for (int i = 0; i < 5; i++) {
				soup = Instantiate (cube);
				soup.transform.position = new Vector3 (j, x, -0.01F);
				soup.GetComponent<Renderer> ().material.mainTexture = letters [w];
				soup.gameObject.tag = "Blue";
				j++;
				if (w == 2) {
					w = 7;
				} else {
					if (w == 7) {
						w = 0;
					} else {
						if (w == 0) {
							w = 8;
						} else {
							w = 17;
						}
					}
				}
			}
		} else {
			if (p == 1) {
				for (int i = 0; i < 5; i++) {
					soup = Instantiate (cube);
					soup.transform.position = new Vector3 (x, j, -0.01F);
					soup.GetComponent<Renderer> ().material.mainTexture = letters [w];
					soup.gameObject.tag = "Blue";
					j++;
					if (w == 2) {
						w = 7;
					} else {
						if (w == 7) {
							w = 0;
						} else {
							if (w == 0) {
								w = 8;
							} else {
								w = 17;
							}
						}
					}
				}
			} 

		}
	}
	}