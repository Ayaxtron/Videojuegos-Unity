﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScriptCube : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame

	void OnMouseDown(){
		
		Change ();
	}

	void Change(){
		gameObject.GetComponent<Renderer> ().material.color = Color.yellow;

	}
}
